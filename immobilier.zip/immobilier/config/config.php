<?php

// Fichier de configuration  -Variables globales-

$siteName = 'Immobilier';
$slogan = 'Votre logement en ligne';

// Page courante et titre de la balisa title
// $currentPageTitle = (empty($currentPageTitle)) ? NULL : $currentPageTitle;
$currentPageUrl = basename($_SERVER['REQUEST_URI'], '.php');
