INSERT INTO `immobilier`.`type` (`nom`) VALUES ('location');
INSERT INTO `immobilier`.`type` (`nom`) VALUES ('vente');
